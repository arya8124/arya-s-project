import express, { Request, Response } from 'express';  
import sequelize from './config/db';
import cors from 'cors';
import transportRoutes from './routes/transportRoutes';
const app = express();
app.use(express.json()); 
app.use(cors());
// Routes
app.use('/api/transports', transportRoutes);
const PORT = process.env.PORT || 8000;

sequelize.sync()
    .then(() => {
        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });
    })
    .catch((err: Error) => {
        console.error('Unable to connect to the database:', err);
});