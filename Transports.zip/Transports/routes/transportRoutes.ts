import { response, Router } from 'express';
import { Request, Response } from 'express';
import {addTransport, getTransports,
    getTransportById,getOrderAndTransportDetails , updateTransport, deleteTransport }from '../controller/transportController';

const router= Router();
router.get('/order/combine/:id', (req:Request,res:Response)=>{getOrderAndTransportDetails(req,res)} );
router.post('/add', addTransport); 
router.get('/list', getTransports);  
router.get('/:id', getTransportById); 
router.put('/:id', updateTransport);
router.delete('/:id', deleteTransport); 

export default router;
