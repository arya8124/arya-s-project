import { Sequelize } from 'sequelize';
const sequelize = new Sequelize('transports', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
});
sequelize.authenticate()
    .then(() => {
        console.log('Connection to the database has been established successfully.');
    })
    .catch((err: Error) => {
        console.error('Unable to connect to the database:', err);
    });
export default sequelize;