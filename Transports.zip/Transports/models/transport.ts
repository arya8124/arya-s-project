import { DataTypes, Model } from 'sequelize';
import sequelize from '../config/db';

interface TransportAttributes {
    id?: number;
    companyName: string;
    contactPersonName: string;
    email: string;
    mobileNumber: string;
    materialToTransport: string;
    contractDuration: string;
    status: string;
    ownerName: string;
}

export class Transport extends Model<TransportAttributes> implements TransportAttributes {
    public id!: number;
    public companyName!: string;
    public contactPersonName!: string;
    public email!: string;
    public mobileNumber!: string;
    public materialToTransport!: string;
    public contractDuration!: string;
    public status!: string;
    public ownerName!: string;

    public readonly createdAt!: Date;
    public readonly updatedAt!: Date;
}

Transport.init(
    {
        companyName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        contactPersonName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                isEmail: true,
            },
        },
        mobileNumber: {
            type: DataTypes.STRING,
            allowNull: false,
            validate: {
                isNumeric: true,
                len: [10, 15],
            },
        },
        materialToTransport: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        contractDuration: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        status: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        ownerName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    },
    {
        sequelize,
        tableName: 'transports',
        timestamps: true,
    }
);
export default Transport;
