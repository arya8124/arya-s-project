import { Request, Response } from "express";
import axios from "axios";
import { Op } from "sequelize";
import Transport from "../models/transport";

export const addTransport: any = async (req: Request, res: Response) => {
  try {
    const {
      companyName,
      contactPersonName,
      email,
      mobileNumber,
      materialToTransport,
      contractDuration,
      status,
      ownerName,
    } = req.body;

    const existingTransport = await Transport.findOne({
      where: {
        companyName,
        email,
        mobileNumber,
        ownerName,
      },
    });
    if (existingTransport) {
      return res.status(400).json({ message: "Transporter already exists." });
    }
    const transport = await Transport.create({
      companyName,
      contactPersonName,
      email,
      mobileNumber,
      materialToTransport,
      contractDuration,
      status,
      ownerName,
    });

    res
      .status(201)
      .json({
        status: "okay",
        message: "Transporters added successfully",
        transport,
      });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
};
export const getOrderAndTransportDetails = async (
  req: Request,
  res: Response
) => {
  try {
    const id = req.params.id;
    const orderResponse = await axios.get(
      `http://localhost:8080/api/orders/${id}`
    );
    console.log("Getting order id ", getOrderAndTransportDetails);

    const transport = await Transport.findOne({
      where: { id },
    });
    if (!transport) {
      return res
        .status(404)
        .json({ status: "Unsuccessful", message: "Transport Not found" });
    }

    const combinedDetails = {
      orderDetails: orderResponse.data,
      transportDetails: transport ? transport : null,
    };
    res.status(200).json({
      status: "sucess",
      message: "Combined details of transporter and orders",
      combinedDetails,
    });
  } catch (error: any) {
    console.error("Error to fatching details", error.message);
    res
      .status(500)
      .json({ message: "This order id is not exists in the database" });
  }
};

export const getTransports = async (req: Request, res: Response) => {
  try {
    const {
      sortBy = "companyName",
      order = "asc",
      search,
      page = 1,
      limit = 10,
    } = req.query;
    const orderDirection = order === "desc" ? "DESC" : "ASC";
    const offset = (parseInt(page as string) - 1) * parseInt(limit as string);

    const searchCondition = search
      ? {
          companyName: { [Op.like]: `%${search}%` },
        }
      : {};

    const transports = await Transport.findAndCountAll({
      where: searchCondition,
      order: [[sortBy as string, orderDirection]],
      limit: parseInt(limit as string),
      offset: offset,
    });

    const totalPages = Math.ceil(transports.count / parseInt(limit as string));

    res.status(200).json({
      totalRecords: transports.count,
      totalPages,
      currentPage: parseInt(page as string),
      pageSize: parseInt(limit as string),
      transports: transports.rows,
    });
  } catch (error: any) {
    res
      .status(500)
      .json({ error: "Failed to retrieve transports", details: error.message });
  }
};

// Get Transport by ID
export const getTransportById: any = async (req: Request, res: Response) => {
  try {
    const transport = await Transport.findByPk(req.params.id);

    if (!transport) {
      return res.status(404).json({ error: "Transport not found" });
    }

    res.status(200).json(transport);
  } catch (error: any) {
    res
      .status(500)
      .json({ error: "Failed to retrieve transport", details: error.message });
  }
};

// Update Transport
export const updateTransport: any = async (req: Request, res: Response) => {
  try {
    const transport = await Transport.findByPk(req.params.id);

    if (!transport) {
      return res.status(404).json({ error: "Transport not found" });
    }

    const {
      companyName,
      contactPersonName,
      email,
      mobileNumber,
      materialToTransport,
      contractDuration,
      status,
      ownerName,
    } = req.body;

    await transport.update({
      companyName,
      contactPersonName,
      email,
      mobileNumber,
      materialToTransport,
      contractDuration,
      status,
      ownerName,
    });

    res.status(200).json(transport);
  } catch (error: any) {
    res
      .status(500)
      .json({ error: "Failed to update transport", details: error.message });
  }
};

// Delete Transport
export const deleteTransport: any = async (req: Request, res: Response) => {
  try {
    const transport = await Transport.findByPk(req.params.id);

    if (!transport) {
      return res.status(404).json({ error: "Transport not found" });
    }

    await transport.destroy();
    res
      .status(200)
      .json({ status: "okay", message: "Transport deleted successfully" });
  } catch (error: any) {
    res
      .status(500)
      .json({ error: "Failed to delete transport", details: error.message });
  }
};
